var searchData=
[
  ['red',['red',['../problem1_8c_09_09.html#af90824509586333cf45ce757d2711ce3aace9033470c7bfe9523c814271251908',1,'problem1.c++']]]
];
