var searchData=
[
  ['right',['right',['../structnode.html#a51e160f22dc6064bac4a4f9f1d931c2c',1,'node']]],
  ['root',['root',['../problem2_8c_09_09.html#aa570215f2f913275d6ff0d586e436d21',1,'problem2.c++']]],
  ['root_5favl',['root_avl',['../problem1_8c_09_09.html#a68efd9725967ab0a9111a3fc31158ade',1,'problem1.c++']]],
  ['root_5fbst',['root_bst',['../problem1_8c_09_09.html#a651b476c19db65b2d0e7a061700cbf94',1,'problem1.c++']]],
  ['root_5frbt',['root_rbt',['../problem1_8c_09_09.html#af03f2cddd9d511c98d90283c3ee1f8f7',1,'problem1.c++']]]
];
