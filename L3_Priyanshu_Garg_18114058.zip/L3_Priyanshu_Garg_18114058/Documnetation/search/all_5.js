var searchData=
[
  ['head',['head',['../problem2_8c_09_09.html#a4bc3a90bae6b2a4949d3160c629879db',1,'problem2.c++']]],
  ['height',['height',['../structnode.html#a522298f219c14128a6027ee43046ea15',1,'node::height()'],['../problem1_8c_09_09.html#ae4a66d8b0c2b0d626aea45977e358c83',1,'height():&#160;problem1.c++']]]
];
