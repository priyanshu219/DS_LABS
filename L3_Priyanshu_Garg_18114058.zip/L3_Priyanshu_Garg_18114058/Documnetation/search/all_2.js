var searchData=
[
  ['data',['data',['../structnode.html#a2d890bb9f6af0ffd73fe79b21124c2a2',1,'node']]]
];
