var searchData=
[
  ['color',['color',['../structnode.html#a310a09cb5a882788781a5287096ad425',1,'node::color()'],['../problem1_8c_09_09.html#af90824509586333cf45ce757d2711ce3',1,'COLOR():&#160;problem1.c++']]]
];
