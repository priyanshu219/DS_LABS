var searchData=
[
  ['transverse_5fnode',['transverse_node',['../problem1_8c_09_09.html#adf38af92ad12705aa7607a48d0c8c125',1,'transverse_node(node *root, int flag):&#160;problem1.c++'],['../problem__1_8c_09_09.html#adf38af92ad12705aa7607a48d0c8c125',1,'transverse_node(node *root, int flag):&#160;problem_1.c++']]]
];
