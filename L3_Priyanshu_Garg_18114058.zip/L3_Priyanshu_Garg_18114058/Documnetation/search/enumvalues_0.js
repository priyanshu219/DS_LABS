var searchData=
[
  ['black',['black',['../problem1_8c_09_09.html#af90824509586333cf45ce757d2711ce3a775364fe1f3fffe99686bf6d572a7370',1,'problem1.c++']]]
];
