var searchData=
[
  ['color',['color',['../structnode.html#a310a09cb5a882788781a5287096ad425',1,'node']]]
];
