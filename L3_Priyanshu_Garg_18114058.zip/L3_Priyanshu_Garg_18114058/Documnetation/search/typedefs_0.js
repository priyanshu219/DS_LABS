var searchData=
[
  ['node',['node',['../problem1_8c_09_09.html#ace29f146c273d2654669dc2c710603e2',1,'node():&#160;problem1.c++'],['../problem2_8c_09_09.html#ace29f146c273d2654669dc2c710603e2',1,'node():&#160;problem2.c++']]]
];
