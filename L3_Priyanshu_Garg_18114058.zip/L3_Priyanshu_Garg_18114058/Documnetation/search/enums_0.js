var searchData=
[
  ['color',['COLOR',['../problem1_8c_09_09.html#af90824509586333cf45ce757d2711ce3',1,'problem1.c++']]]
];
